# Social Media Campaign Performance Tracker

## Objective
Analyze Facebook/Instagram ad campaigns to measure engagement, CTR, ROI, and conversions.

## Skills Demonstrated
- Marketing analytics
- Campaign optimization
- Interactive dashboard storytelling

## Dataset
- `social_campaign_sample_500.csv` — sample campaign data with Spend, Clicks, Impressions, Conversions, Revenue, Engagement

## Instructions
1. Load CSV into Power BI / Excel / Looker Studio.
2. Clean data using Power Query if required.
3. Create calculated columns/measures (CTR, CPC, CPM, ROI).
4. Build visuals following recommended dashboard layout.
5. Publish and/or upload `.pbix` / dashboard screenshots to GitHub.
