# Ecommerce Sales Dashboard - Basic Project (Student Level)

This repository package contains a ready-made dataset and all necessary scripts/instructions to quickly build the Power BI dashboard for the **Business Sales Dashboard (E-commerce Data)** student task.

## What is included
- `data_ecommerce_sample_500.csv` — Sample dataset (500 rows)
- `powerquery_m.txt` — Power Query M script to import & clean the CSV in Power BI
- `dax_measures.txt` — Ready-to-paste DAX measures for Power BI
- `Business_Sales_Dashboard_INSTRUCTIONS.txt` — Step-by-step instructions to build the `.pbix` quickly
- `README.md` — This file

> Note: I cannot generate a real `.pbix` (Power BI desktop file) within this environment. Instead, this package includes everything you need to recreate the dashboard in **Power BI Desktop** in under 10 minutes.

## Quick steps to create the Power BI file
1. Download and unzip this package.
2. Open **Power BI Desktop**.
3. On **Home → Get data → Text/CSV**, select `data_ecommerce_sample_500.csv` and click **Load**.
4. In **Transform Data**, open the Advanced Editor and replace with the contents of `powerquery_m.txt` (or apply transformations manually). Click **Close & Apply**.
5. Create a Date table: Model → New Table, or use Power Query to generate a `DimDate` covering the date range.
6. Paste the DAX measures from `dax_measures.txt` into a new Measures table.
7. Build visuals following the recommended layout in `Business_Sales_Dashboard_INSTRUCTIONS.txt` (KPIs, trend line, top products, category treemap).
8. Save the file as `Business_Sales_Dashboard.pbix` and push to your GitHub repo.

## License
Use freely for learning and student submissions.
